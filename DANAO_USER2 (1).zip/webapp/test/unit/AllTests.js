sap.ui.define([
	"MDG/MDG_Test/test/unit/controller/App.controller"
], function () {
	"use strict";
});